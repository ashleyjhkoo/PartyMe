 // Materialize - sideNave screen - Start   
 $('#hamPic').click(function() {
     // Show sideNav
  $('.button-collapse').sideNav('show');
  // Hide sideNav
  // $('.button-collapse').sideNav('hide');
   
   $(".button-collapse").sideNav();
   $('.collapsible').collapsible();

   $('.button-collapse').sideNav({
   menuWidth: 300, // Default is 240
   edge: 'right', // Choose the horizontal origin
   closeOnClick: true // Closes side-nav on <a> clicks, useful for Angular/Meteor
   }); 

 });

  // Initialize collapse button
  // $(".button-collapse").sideNav();
  // Initialize collapsible (uncomment the line below if you use the dropdown variation)
  // $('.collapsible').collapsible();

 // $('.button-collapse').sideNav({
 //   menuWidth: 300, // Default is 240
 //   edge: 'right', // Choose the horizontal origin
 //   closeOnClick: true // Closes side-nav on <a> clicks, useful for Angular/Meteor
 // });
 // Materialize - sideNave screen - End  
